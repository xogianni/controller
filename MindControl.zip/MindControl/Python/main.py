import pygame
from pygame.locals import *
import config
import sys


pygame.init()


screen=pygame.display.set_mode([config.screen_width, config.screen_height])
pygame.display.set_caption("EEGTest")

keep_going = True
character = pygame.image.load("images/red.png")
x = 0
y = 0
black = (0,0,0)

screen.blit(character, (x,y))
pygame.display.update()

while keep_going:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            keep_going = False
            pygame.display.QUIT()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_d:
                x += 20
                screen.fill(black)
                screen.blit(character, (x, y))
                pygame.display.update()
                if x >= 760:
                    x = 760
            elif event.key == pygame.K_a:
                x -= 20
                screen.fill(black)
                screen.blit(character, (x, y))
                pygame.display.update()
                if x <= 20:
                    x = 20
            elif event.key == pygame.K_w:
                y -= 20
                screen.fill(black)
                screen.blit(character, (x, y))
                pygame.display.update()
                if y <= 0:
                    y = 0
            elif event.key == pygame.K_s:
                y += 20
                screen.fill(black)
                screen.blit(character, (x, y))
                pygame.display.update()
                if y >= 550:
                    y = 550
