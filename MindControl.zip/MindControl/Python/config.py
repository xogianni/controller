screen_width=800
screen_height=600