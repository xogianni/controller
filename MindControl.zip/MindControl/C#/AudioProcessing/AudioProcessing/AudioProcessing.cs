﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NAudio;
using NAudio.Wave;
using System.IO;
using System.Windows.Forms;
using System.Drawing;

namespace AudioProcessing
{
    class AudioProcessing
    {
        int value = 0;
        public float max = 0;
        public string outputFilename = @"C:\Users\docmo\Documents\MindControl\C#\Audio Saves\current.wav";
        WaveIn waveInStream;
        WaveFileWriter writer;
        bool BadDataFlag;

        public void record()
        {
            waveInStream = new WaveIn();
            writer = new WaveFileWriter(outputFilename, waveInStream.WaveFormat);

            waveInStream.DataAvailable += new EventHandler<WaveInEventArgs>(waveInStream_DataAvailable);
            waveInStream.StartRecording();

            void waveInStream_DataAvailable(object sender, WaveInEventArgs e)
            {
                writer.Write(e.Buffer, 0, e.BytesRecorded);


                for (int index = 0; index < e.BytesRecorded; index += 2)
                {
                    short sample = (short)((e.Buffer[index + 1] << 8) |
                                            e.Buffer[index + 0]);

                    var sample32 = sample / 32768f;

                    if (sample32 < 0) sample32 = -sample32;

                    if (sample32 > max) max = sample32;
                }
            }
        }

        public void stop()
        {
            waveInStream.StopRecording();
            waveInStream.Dispose();
            waveInStream = null;
            writer.Close();
            writer = null;
        }

        public void detectBadData()
        {
            while (true)
            {
                if(max < value * 4)
                BadDataFlag = true;
            }

            if (BadDataFlag == true)
            {
                while (true)
                {
                    break;
                }
            }
            else if(max > value)
            {
                SendKeys.Send("w");
            }
        }
    }
}
